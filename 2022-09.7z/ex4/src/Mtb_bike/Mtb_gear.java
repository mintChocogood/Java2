package Mtb_bike;


public interface Mtb_gear {
	public int Max_gear = 5;
	public int Min_gear = 1;
	
	
	// 톱니 40개 단수가 올라갈 때 마다 5개씩 오름
	public abstract int Gear_Stage(int c);
		
		
		
	
	
	
	
	
	
	
	
	
	
	
} // interface
