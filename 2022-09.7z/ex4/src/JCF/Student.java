package JCF;

public class Student {

}
