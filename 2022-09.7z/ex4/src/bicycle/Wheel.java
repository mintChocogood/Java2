package bicycle;

public class Wheel {
	
	void 굴러가다() {
		System.out.println("바퀴가 굴러간다");
	}

}
