package pa.pb;

import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@NoArgsConstructor
public class Car {	// Mock-up/Stub class, POJO(Plain Old Java Object)
	;;
}
