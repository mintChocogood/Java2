package 연습;

public class SubString {

	public static String getSmallestAndLargest(String s, int k) {
        String smallest = "";
        String largest = "";
        
        
        return smallest + "\n" + largest;
	}
} // end class
