package bicycle02;

@FunctionalInterface
public interface IBrake {
	
	public abstract void hold();

} // end interface
