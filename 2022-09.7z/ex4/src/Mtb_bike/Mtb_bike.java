package Mtb_bike;

public interface Mtb_bike 
extends Mtb_brake, Mtb_chain, Mtb_gear, Mtb_handle, Mtb_kickStand, Mtb_lock,
Mtb_pedal, Mtb_saddle, Mtb_wheel, Mtb_bell {
	
	
	
} // interface
