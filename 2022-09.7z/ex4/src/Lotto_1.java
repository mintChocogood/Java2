
public class Lotto_1 {

	public static void main(String[] args) {
		System.out.println("선택한 번호는");
//	      int A = 0;
//	      int C = 1;
//	      
//	      boolean run = true;
//	        while(A <=6 ) {
//	        	A++;
//	        	int B = (int)(Math.random()*6)+1;
//	        	for(run) {
//	        		C++;
//	        		
	        		
//	        	}
		
	        
	        
	        
//	        } //while class
		int b =1;
		
		while( b<=0) {
			b++;
			int a = (int)(Math.random()*6)+1;
		
			
		if(a == a) {
				break;
		}
			
			System.out.println(a);
		
			
		
			
		}
		
		
		
		
		
		
		
		
} // main class
	
} // end class
