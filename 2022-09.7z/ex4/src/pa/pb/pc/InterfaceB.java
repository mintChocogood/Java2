package pa.pb.pc;

public interface InterfaceB {
	
	public abstract void 메소드B();
	
}
