package bicycle_polymorphism;


//핸들인터페이스
public interface Handle {
	
	public abstract void turnright();
	public abstract void turnleft();
	public abstract void turnback();
	
	//핸들의 방향전환 메소드

}//end interface
