package Mtb_bike;

public interface Mtb_kickStand {

	public abstract void put_on();			// 지지대를 세움
	
	public abstract void pull_down();		// 지지대를 내림
	
} // interface
