package bicycle;

public class Chain {
	
	Pedal pedal = new Pedal();
	void go() {
		System.out.println(pedal+"을 밟아 체인이 돌아감");
	}
}
