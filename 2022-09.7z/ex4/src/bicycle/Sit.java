package bicycle;

public class Sit {

	void sitDown() {
		System.out.println("앉음");
	}
}
