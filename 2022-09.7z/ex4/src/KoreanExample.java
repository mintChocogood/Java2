
public class KoreanExample {

	
	public static void main(String[] args) {

		Korean k1 = new Korean("박자바", "011225-1234567"); // 1. 객체 생성
		System.out.println("2. k1: " + k1.name);            // 2. 필드값 출력
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	} // main

} // end class
