
public class Sample42_continue3 {

	public static void main(String[] args) {
		
		for(int i=1; i <= 10; i++) {
			if(i == 8) continue;
			
			System.out.println("i =" + i);
		}// for
	
	} //main
} // end class
