package bicycle_polymorphism;

public interface Brake {
	
	public abstract void stop();

}//end interface
