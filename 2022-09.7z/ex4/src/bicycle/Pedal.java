package bicycle;

public class Pedal {
	void press() {
		System.out.println("페달을 밟음");
	}

}
