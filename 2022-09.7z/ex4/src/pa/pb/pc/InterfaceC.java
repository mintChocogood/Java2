package pa.pb.pc;


public interface InterfaceC extends InterfaceA, InterfaceB {
	
	public abstract void 메소드C();
	
} // end interface
