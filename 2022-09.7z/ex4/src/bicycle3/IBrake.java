package bicycle3;

@FunctionalInterface
public interface IBrake {
	
	
	public abstract void stop();
	
} // end interface
