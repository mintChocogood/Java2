package bicycle3;

@FunctionalInterface
public interface ILock {

	
	public abstract void lock();
	
} // end interface
