
public class Sample2 {
	
	public static void main(String[] args) {

		int age = 29;
		
		System.out.println(age);
	    
		int miea = 2022 - 1994 + 1;
				
				System.out.println(miea);
		
		int value = 10;
		
		int result = value + 10;
		
		System.out.println(result);
		
		int sence = 3;
		
		int bite = 7;
		
		System.out.println (sence + bite);
		
		int mean;
		System.out.println("============================");
		System.out.println("1. Literal: " + 100);
		System.out.println("2. Variale: " + result);
		System.out.println("3. Operation: " + (value + 10));
	
		
		
		
 		
		
	}

} 