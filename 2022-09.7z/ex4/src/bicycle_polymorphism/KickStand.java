package bicycle_polymorphism;

//지지대 인터페이스
public interface KickStand {
	
	public abstract void upper();
	public abstract void lower();
	
	//지지대 올리고 내리기 메소드

}//end interface
