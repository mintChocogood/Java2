package bicycle;

public class Unlock {
	void on() {
		System.out.println("열림");
	}
	void off() {
		System.out.println("잠김");
		
	}

}
