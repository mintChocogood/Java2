
public class 연습 {

	public static void main(String[] args) {
		
	
	
	
	try {
		
	}catch(NullPointerExceptinExample e) {
		
		
	}finally {
			
		}
	}

}