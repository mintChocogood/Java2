
public class Sample5 {
	
	public static void main(String[] args) {
		
		String name = "홍기서";
		double weight = 86.9;
		double height = 172.3;
		int age = 29;
		String adress = "경기도 안양시 안양7동 메가트리아 116동 702호";
		boolean isAlive = true;
		
		boolean good = true;
		boolean bad = false;
		
	

		System.out.println(name);
		System.out.println(weight);
		System.out.println(height);
		System.out.println(age);
		System.out.println(adress);
		System.out.println(isAlive);

		
	}

}
