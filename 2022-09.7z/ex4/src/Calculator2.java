
public class Calculator2 {

	static double pi = 3.14159;
	
	
	
	static int 덧셈(int x, int y) {
		return x + y;
	} // plus
	
	static int 뺄셈(int x, int y) {
		return x - y;
	} // minus
	
	
	
	
} // end class
