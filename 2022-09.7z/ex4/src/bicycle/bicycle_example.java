package bicycle;

public class bicycle_example {

	public static void main(String[] args) {
		
		Bicycle b1 = new Bicycle("1번 자전거",20,"나");
		b1.p();
		b1.s();
		
		Bicycle b2 = new Bicycle("2번 자전거",10,"다른사람");
		b2.wheel();
		
		Bicycle b3 = new Bicycle("3번 자전거", 0 ,null);

		
		
		
	} // main
	
} // end class
  