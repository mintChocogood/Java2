package pa.pb.pc;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class A {
	;;
	
} // end class
