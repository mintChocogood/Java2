package pa.pb;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class A {
	;;
} // end class
