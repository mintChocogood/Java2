
public class Sample26 {

	// 단순 if문 예제입니다.
	// 즉, 조건식이 참(true)일 때만을 고려한 제어문 중의 하나
	public static void main(String[] args) {
		
		int score = 93;
		
		if(score>=90) { //단순 if 문
			System.out.println("점수가 90보다 큽니다.");
			System.out.println("등급은 A 입니다.");
		} //if
		
		// {} 생략시, 버그를 자신도 모르게 유발 가능하다!! --> 생략하지 마라!
		if(score < 90) { // 단순 if 문
			//System.out.println("점수가 90보다 작습니다.");
			//System.out.println("등급은 B입니다.");
			
		}
		
		
		
		
		
		
		
		
		
	}
}
