
public class Sample12 {

	public static void main(String[] args) {
	/*	
		int x = 10;
		int y = 10;
		int z;
		
		
		x++;
		
		
		System.out.println(" 1 . x = " + x);
		
		++x;
		
		System.out.println(" 2. x = " + x);
		
		int result = x + 1;
		
		int result2 = ++x + 1;
		
		int result3 = (x++) + 1;
		
		System.out.println(result2);
		System.out.println(result3);
		*/
		
		
		
		int x = 10;
		
		++x;
		
		System.out.println(x);
		
		int y = 10;
		
		y = y + 1;
		
		int result3 = y + 1;
		
		System.out.println(y);
		
		//으렵따! 코딩은 간단하고 짧게하는것보다 풀어쓰더라도
		//보기쉽게 하는것이 중요**
	
		
	/* 증가연산자 적용(단항) - 후위 증가연산자 (x++;)
	 * 증가연산자 적용(단항) - 전위 증가연산자 (++x;)*/	
	 
	}
}
