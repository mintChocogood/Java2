package bicycle02;

public interface IVehicle extends ISaddle, IPedal { // 탈것

	;;
	
} // end interface
