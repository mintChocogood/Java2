package Package1;



@어노테이션("기서")
public class Test {
	private int 나이;
	
	public Test() {
		;;
	} // 기본생성자
	
	public void instanceMethod(int 나이) {
		;;
	}
	
	public static void staticMethod() {
		;;
	}
	
} // end class
