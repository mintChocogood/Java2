package bicycle_polymorphism;

//잠금장치 인터페이스
public interface Lock {
	
	public abstract void lock();
	public abstract void unlock();

}//end interface
