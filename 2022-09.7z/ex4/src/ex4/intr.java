package ex4;

public class intr {
	
	public static void main(String[] args) {
	int num1 = 2;
	int num2 = 0;
	
	try {
		System.out.println("두 수의 나눗셈 결과 : " + num1 / num2);
	} catch(ArithmeticException e) {
		
	}
	
	
	} // main
	
	
	
	
	
	
	
	
} // end class
