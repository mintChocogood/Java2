
public class FieldInitValue {
	// 1. 기본타입의 필드
	byte byteField;             // 정수타입 = 0
	short shortField;
	int intField;
	long longField;
	
	boolean booleanField;;      // 불린타입 = false
	char charField;             // 문자타입 = 16진수로 0 (=10진수 0) => ''(빈 문자)
	
	float floatField;           // 실수타입 = 0.0
	double doubleField;
	
	// 2. 참조타입의 필드 =>       기본값 : null
	int[] arrField;
	String referenceField;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
} // end class
