
public class Sample15 {

	public static void main(String[] args) {
		
		int v1 = 9;
		int v2 = 7;
		
		int result1 = v1 + v2; 
	    System.out.println( "1. result=" + result1);
				
		int result2 = v1 - v2;
		System.out.println( "2. result2=" + result2);
		
		int result3 = v1 * v2;
		System.out.println( "3. result3=" + result3);
		
		int result4 = v1 / v2;
		System.out.println( "4. result4=" + result4);
		
		int result5 = v1 % v2;
		System.out.println( "5. result5=" + result5);
		
		double result6 = v1 / (double) v2;
		System.out.println( "6. result6=" + result6);
		
		
		
		
		
		
		
		
		
				

		
	
	
		
		
	}
}
