package Package1;

public class Airplane {	// 부모 클래스의 역할 수행: 모든 종류의 의미
	
	
	public void land() {		
		System.out.println("항공기 착륙 호출");
		
	} // land
	
	public void fly() {
		System.out.println("항공기 비행 호출");
		
	} // fly
	
	public void takeOff() {
		System.out.println("항공기 이륙 호출");
		
	} // takeOff
	
	
} // end class
