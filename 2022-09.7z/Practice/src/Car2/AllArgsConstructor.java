package Car2;

public @interface AllArgsConstructor {

}
