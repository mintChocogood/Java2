
public class Television {
	
	static String company = "삼성";
	static String model = "LCD";
	static String info;
	
	static {
			info = company + "-" + model;
			System.out.println(info);
}
	

}
