
public class Sample30 {

	public static void main(String[] args) {
		
		int max = 45;
		int min = 1;		
		int num = (int)(Math.random() * (max-min+1)) + min;
		
		System.out.println(num);
		
		
		
		
		
		
	}
}
