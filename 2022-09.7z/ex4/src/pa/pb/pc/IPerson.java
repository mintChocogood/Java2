package pa.pb.pc;

@FunctionalInterface
public interface IPerson {

	public abstract void sleep();
	
} // end class
