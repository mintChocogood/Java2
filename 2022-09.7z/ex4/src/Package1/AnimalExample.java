package Package1;

import java.util.Iterator;

public class AnimalExample {

	public static void main(String[] args) {
		
		
		
	}
}
