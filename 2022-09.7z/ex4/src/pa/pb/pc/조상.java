package pa.pb.pc;

public class 조상 implements 단군할아버지{

	
	;;
	
	
	
	
	
	
	
} // end class

class 부모1 extends 조상{;;}
class 부모2 extends 조상{;;}
class 부모3 extends 조상{;;}

class 자식1 extends 부모1{;;}
class 자식2 extends 부모2{;;}
class 자식3 extends 부모3{;;}

interface 단군할아버지 {;;}