package bicycle_polymorphism;


//페달인터페이스
public interface Pedal {
	
	public abstract void stepOn(String degreeOfPedaling); 
	//밟는정도를 매개변수로 하는 밟기 메소드
	//빠른속도로, 느린속도로, 보통속도로

}//end interface
