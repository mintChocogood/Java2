import java.util.Arrays;

public class Sample52 {

	public static void main(String[] args) {

		
		
		
		
	}

}
