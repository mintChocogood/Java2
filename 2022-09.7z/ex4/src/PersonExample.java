
public class PersonExample {

	public static void main(String[] args) {  // 메소드이다! => 즉, 객체의 행위
		
		
		Person instance = new Person("기서", 20);
		System.out.println("2. 실행 클래스에서 출력한 참조변수: " + instance);
		
		
		
		
		
								// 전달인자(Arguments)//
								//-------------//
//		Person p1 = new Person("기서", 20);
//		System.out.println("3. p1.name: " + p1.name);
//		System.out.println("4. p1.age: " + p1.age);
		
//		========================================
		
//		Person p2 = new Person("트리니티", 18);
//		System.out.println("5. p2.name: " + p2.name);
//		System.out.println("6. p2.age: " + p2.age);
		
		
		
 	} // main

} // end class
