package pa.pb.pc;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class B  extends A{
	;;
	
} // end class
