package pa.pb.pc;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class D extends B{
	;;
	
} // end class
