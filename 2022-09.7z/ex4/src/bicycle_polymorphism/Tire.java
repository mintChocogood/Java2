package bicycle_polymorphism;

//자전거바퀴 인터페이스????
public interface Tire {
	public static final int MAX_airPressure = 10;
	public static final int MIN_airPressure = 0;
	//공기압 정도
	
	
	public void roll();

}//end interface

