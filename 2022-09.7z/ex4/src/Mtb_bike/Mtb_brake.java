package Mtb_bike;

public interface Mtb_brake {
	public abstract void brake();
	
	
} // interface
