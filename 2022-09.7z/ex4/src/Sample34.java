
public class Sample34 {

	public static void main(String[] args) {
		
		
		// 실수타입으로 카운터 변수를 사용하면 안된다!
		for(float x = 0.1f; x <= 1.0f; x += 0.1f) {
			System.out.println(x);
			
			
		}
	}
	
	
}
