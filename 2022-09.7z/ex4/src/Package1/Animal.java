package Package1;

public class Animal {
	String sound;
	
	
	public Animal() {
		;;
	}
	
} // end class
