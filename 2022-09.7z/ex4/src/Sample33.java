
public class Sample33 {

	public static void main(String[] args) {
       
		
//		int result = 0;
//		int counter = 1;
//		
//		for( ; ; ) {
//			result = result + counter;
//			
//			
//			
//			
//			
//			
//			++counter;
//		
//		
//		} // for
//		
		
//		System.out.println("* result = " + result);
//		System.out.println("* counter = " + counter);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*int result = 0;
		
		for(int counter=1; counter <= 10; counter++) {
			result = result + counter;
			
			
		} // for
		System.out.println("* result = " + result);
		*/
		
		
//		===========================================
		
//		int sum = 0;
//		int i = 1;
//		
//		for(;;) {  // 무한루프 = 무한히 반복되는 루프를 생성
//			       // 반드시, 탈출 조건을 넣어야 한다.
////			sum += i;    // 복합 대입연산자 +=
//			sum = sum + i; // << sum값과 i 값은 무한루프되는 동안 누적됨
//			
//			++ i;
//			
//			if(i > 10) {   // 탈출조건
//				break;
//				
//			} // if
//		} // for
//			//System.out.println("1~" + (i-1) + "합 : " + sum); 
//		
//		
//		// 초기식의 1 변수의 이름 = (1) 카운터 변수, (2) loop control variable
//	//	for(int i =1; i<=10; i++) {
//		//	System.out.println(i);
////		}   
//	--------------------------------------------
	
	
//		long start = System.currentTimeMillis(); // 현재 시간을 구합니다.
//		
//		
//	for (long j = 1; j <= 10000000L; j++); // 시간을 측정할 테스트 코드
//	 
//	
//	long end = System.currentTimeMillis(); // 테스트 코드의 종료 이후 시간을 구합니다.
//	
//	System.out.println(" * Elapsed time = " + (end - start) + "ms");
//		
	
		
	
	
	
	
		
		
		
		
		
	}
	
}
