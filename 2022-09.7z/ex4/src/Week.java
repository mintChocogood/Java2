
public enum Week {

	MONDAY,     // 객체 ---> "열거상수"
	TUESDAY,    
	WEDNESDAY,  
	THURSDAY,	
	FRIDAY,	
	SATURDAY,
	SUNDAY
	
}    // end num
