package pa.pb.pc;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class E extends C{
	;;
	
} // end class
