package bicycle02;

@FunctionalInterface
public interface ILock {

	public abstract void isLock(boolean lock);
	
} // end interface
