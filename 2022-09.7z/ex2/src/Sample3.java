
public class Sample3 {
	
	public static void main(String[] args) {
		// int var1 = 10;
		
		int var1; // 변수의 선언
		var1 = 100; // 변수의 초기화 => 변수를 "정의" => 변수는 사용가능
		
		System.out.println(var1);
		
		int var2 = 010;
		System.out.println(var2);
		
		int var3 = 0x10;
		System.out.println(var3);
		
		
	}

}
