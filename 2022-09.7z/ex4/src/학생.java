

public class 학생 {

} // end class
