package Mtb_bike;

public interface Mtb_lock {

	public abstract void lock_On();
	
	public abstract void lock_Off();
	
}
