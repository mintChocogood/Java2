
public class Sample9 {

	public static void main(String[] args) {
		
		byte bytevalue = 10;
		int intvalue = bytevalue;  // 자동 형변환(Promotion)
		
		System.out.println(intvalue);
		
//      ----------------
		
		/*char charvalue = '가';      //2바이트의 정수타입(char)
		int intvalue = charvalue;   //Lvalue(4바이트 정수)
		
		System.out.println("가의 유니코드=" + intvalue);
		
//		
 
		
		int intvalue = 500;
		
		long longvalue = intvalue;
		System.out.println(longvalue);
		
//      ----------------
		
		int intvalue = 200;
		
		double doublevalue = intvalue;
		System.out.println(doublevalue);
		
		*/
		
		
		
		
		
		
		
		
	}
}
