
public class 계산기 {

	int x;
	int y;
	
	public int 더하기(int x, int y) {
		int result = x + y;
		System.out.println("더하기 실행");
		return result;
	} // 더하기
	
	public static int 빼기(int x, int y) {
		int result2 = x - y;
		System.out.println("빼기 실행");
		return result2;
	}
	
} // end class
