package pa.pb;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class HighStudent extends Student {

	public HighStudent(String name) {
		super(name);
	} // 생성자

} // end class
