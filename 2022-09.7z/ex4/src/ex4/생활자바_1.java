package ex4;

public class 생활자바_1 {

	public static void main(String[] args) {

		
		int a = 1;
		int b = 2;
		int c = 3;
		int d = 4;
		int e = 5;
		int f = 6;
		int g = 7;
		int h = 8;
		int i = 9;
		int j = 10;
		int k = 11;
		int l = 12;
		int m = 13;
		int n = 14;
		int o = 15;
		int p = 16;
		int q = 17;
		int r = 18;
		int s = 19;
		int t = 20;
		int u = 21;
		int v = 22;
		int w = 23;
		int x = 24;
		int y = 25;
		int z = 26;
		int A = 27;
		int B = 28;
		int C = 29;
		int D = 30;
		int E = 31;
		int F = 32;
		int G = 33;
		int H = 34;
		int I = 35;
		int J = 36;
		int K = 37;
		int L = 38;
		int M = 39;
		int N = 40;
		int O = 41;
		int P = 42;
		int Q = 43;
		int R = 44;
		int S = 45;
//		
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(e);
//		System.out.println(f);
//		System.out.println(g);
//		System.out.println(h);
//		System.out.println(i);
//		System.out.println(j);
//		System.out.println(k);
//		System.out.println(l);
//		System.out.println(m);
//		System.out.println(n);
//		System.out.println(o);
//		System.out.println(p);
//		System.out.println(q);
//		System.out.println(r);
//		System.out.println(s);
//		System.out.println(t);
//		System.out.println(u);
//		System.out.println(v);
//		System.out.println(w);
//		System.out.println(x);
//		System.out.println(y);
//		System.out.println(z);
//		System.out.println(A);
//		System.out.println(B);
//		System.out.println(C);
//		System.out.println(D);
//		System.out.println(E);
//		System.out.println(F);
//		System.out.println(G);
//		System.out.println(H);
//		System.out.println(I);
//		System.out.println(J);
//		System.out.println(K);
//		System.out.println(L);
//		System.out.println(M);
//		System.out.println(N);
//		System.out.println(O);
//		System.out.println(P);
//		System.out.println(Q);
//		System.out.println(R);
//		System.out.println(S);
//		--------------------------
		
		for(int counter = 1; counter<=45; counter++) {
//			System.out.println(counter);
			int number = counter;
//			System.out.println(number);
			
			switch(number) {
			case 1 : System.out.println("1번이 나왔습니다");
			break;
			case 2 : System.out.println("2번이 나왔습니다");
			break;
			case 3 : System.out.println("3번이 나왔습니다");
			break;
			case 4 : System.out.println("4번이 나왔습니다");
			break;
			case 5 : System.out.println("5번이 나왔습니다");
			break;
		} 
			switch(number) {
			case 10 : System.out.println("10번이 나왔습니다");
			break;
			case 20 : System.out.println("20번이 나왔습니다");
			break;
			case 30 : System.out.println("30번이 나왔습니다");
			break;
			case 40 : System.out.println("40번이 나왔습니다");
			break;
			}
//			if(number>39) {
//				System.out.println(number);
//			}
		} // for
		
		if(a == 1) {
			System.out.println("1");
		} else if(b != 2){
			System.out.println("2");
		} else if (c < 5) {System.out.println("c");
			
		}
			
		
		
		
		
		
		
		
		
		
		
		
	} // main

} // end class
