
public class FieldInitValueExample {

	public static void main(String[] args) {
		
		FieldInitValue fiv = new FieldInitValue();
		
		
		System.out.println("1. byteField: " + fiv.byteField);
		System.out.println("2. shortField: " + fiv.shortField);
		System.out.println("3. intField: " + fiv.intField);
		System.out.println("4. longField: " + fiv.longField);
		System.out.println("5. booleanField: " + fiv.booleanField);
		System.out.println("6. charField: " + fiv.charField);
		System.out.println("7. floatField: " + fiv.floatField);
		System.out.println("8. doubleField: " + fiv.doubleField);
		System.out.println("9. arrField: " + fiv.arrField);
		System.out.println("10. referenceField: " + fiv.referenceField);
		
	} // main
} // end class
