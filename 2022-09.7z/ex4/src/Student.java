


// FQCN : Fully-Qualified Class Name
// 패키지이름과 클래스의 이름(simple name)이 합쳐진 단어가 진짜 클래스 이름
public class Student {  // Student : Class's simple name
	;; // pass
	
	
} // end class
