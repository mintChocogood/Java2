package Package1;


// final 키워드를 붙일 수 있는 장소:
// (1) 지역변수 (2) 매개변수 (3) 필드 (4) 클래스 선언부 (5) 메소드

// 핵심: final 키워드를 클래스 선언부에다 붙이면 어떤 의미를 가지는가!?
//       final 클래스는 상속을  불허합니다!!!
public final class Member {
	;;
} // end class
