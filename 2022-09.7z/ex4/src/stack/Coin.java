package stack;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;


@ToString
@Getter
@AllArgsConstructor
public class Coin {			// 100원짜리 동전
	private int value;		// 얼마짜리??
	
	
} // end class
