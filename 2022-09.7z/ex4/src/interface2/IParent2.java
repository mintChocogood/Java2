package interface2;



public interface IParent2 {
	
	public abstract void 메소드2();
	
	
} // end interface
