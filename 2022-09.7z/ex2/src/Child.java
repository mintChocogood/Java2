

public class Child extends A {
	
	;;
	
} // end class
