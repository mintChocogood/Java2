package Package1;

public class People {			// POJO : Plain Old Java Object
	public String name;
	public String ssn;
	
	public People(String name, String ssn) {		
		System.out.println("생성자(이름, 주민번호) 호출");
		this.name = name;
		this.ssn = ssn;
	} // 생성자
	
	
	
	
	
	
	
	
	
} // end class
