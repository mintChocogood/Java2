package pa.pb;

import lombok.NoArgsConstructor;
import lombok.ToString;


// 겁데기만 가진 클래스 => "Mock-up"/"Stub" class 라고 부른다.
@NoArgsConstructor
@ToString
public class Tv {
	;;
} // end class
