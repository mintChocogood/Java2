package Car2;

import lombok.NoArgsConstructor;
@Log4j2
@NoArgsConstructor
public class A {
	private String name;
	private int age;
	
	public void instatnceMethod() {
		
	}

}
