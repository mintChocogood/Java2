package bicycle;

public class Break {
	
	void stop () {
		System.out.println("멈춤");
	}

}
