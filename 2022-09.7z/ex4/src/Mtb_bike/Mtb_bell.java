package Mtb_bike;

public interface Mtb_bell {
	public abstract void bell();
	
}
