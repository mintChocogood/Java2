package pa.pb;

public class Worker extends Person{


	public Worker(String name) {
		super(name);
	} // 생성자
}
