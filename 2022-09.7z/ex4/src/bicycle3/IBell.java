package bicycle3;

@FunctionalInterface
public interface IBell {
	
	
	public abstract void ring();
	
} // end interface
