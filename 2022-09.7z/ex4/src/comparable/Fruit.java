package comparable;

import lombok.AllArgsConstructor;
import lombok.ToString;

@ToString
@AllArgsConstructor
public class Fruit {
	public String name;
	public int price;
	
	
} // end class
