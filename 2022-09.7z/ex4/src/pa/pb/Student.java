package pa.pb;

public class Student extends Person {

	public Student(String name) {
		super(name); 
	} // 생성자

} // end class
