
public class Sample18 {

	public static void main(String[] args) {
		
		int apple = 1;
		
		double pieceUnit = 0.1;
		int number = 7;
		
		double result = apple - number * pieceUnit;
		
		System.out.println("사과 한개에서 0.7 조각을 빼면, " + result + "조각이 남는다.");
		
    //  System.out.println("0.7 조각을 빼면,");
	//	System.out.println(result + " 조각이 남는다.");
		
		
		
		
		/*int a = 10;
		int b = 20;
		int c = 30;
		
		System.out.println(a != b);
		
			*/	
		
		
		
	}
}
