package Mtb_bike;

public interface Mtb_chain {
	;;
} // interface
