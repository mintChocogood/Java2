
public class Test2 {
	public static void main(String[] args) {
		
	int day = 1;
	int high = 0;
	int up = 40;
	int down = 17;
	
	
	

}
}