package interface2;


@FunctionalInterface
public interface IParent1 {
	
	public abstract void 메소드1();
	
} // end interface
