package bicycle_polymorphism;

//벨 인터페이스
public interface Bell {
	
	public abstract void ring();

}//end interface
