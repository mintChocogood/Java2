package bicycle3;

@FunctionalInterface
public interface IGear {
	
	
	public abstract void changeGear(int num);
	
} // end interface
