/** : Document Comment (문서 주석)
 * 
 */

/**
 * @author user2
 *
 */
//@MyAnnotion			// OK
//@MyAnnotion package   // OK
package Package1.test;

