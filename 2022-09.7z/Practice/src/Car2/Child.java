package Car2;

import lombok.NoArgsConstructor;

@AllArgsConstructor
public class Child extends A{

}
