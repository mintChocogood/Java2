package 연습;

public class 코인 {
	int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	
}
