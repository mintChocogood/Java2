package bicycle3;

@FunctionalInterface
public interface IKickStand {

	
	public abstract void kickStand();
	
} // end interface
