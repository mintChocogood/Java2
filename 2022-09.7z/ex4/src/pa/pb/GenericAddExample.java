package pa.pb;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class GenericAddExample {

	public static void main(String[] args) {
		제네릭_전자계산기ver<Integer> calc = new 제네릭_전자계산기ver<>();
		
		double result = calc.add(100, 200);
		log.info("result = {}" , result);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	} // main

} // end class
