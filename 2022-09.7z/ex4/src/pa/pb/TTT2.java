package pa.pb;

public class TTT2<T> {

	
	public <T extends Box> int 메소드(T t) {
		return 0;
	} // 메소드
	
	
	
	
} // end class