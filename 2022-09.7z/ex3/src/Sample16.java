import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

//@AllArgsConstructor
@NoArgsConstructor

public class Sample16 {
	
	public static void main(String[] args) {
		
		char c1 = 'A' + 1;   // 여기서, '+'는 산술덧셈연산자
		char c2 = 'A';       // char 타입
		
		
		System.out.println("c1: " + c1);
		System.out.println("c2: " + c2);
		
		System.out.println((int) c2);
		
		
		
		
		
		
		
	}
}

