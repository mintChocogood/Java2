package pa.pb.pc;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@NoArgsConstructor
public class 동물 {
	
	public void 사운드() {
		log.trace("일론머스크 울음소리 호출");
		
		log.info("화성 갈끄니까아ㅏㅏㅏㅏ");
	} // 사운드
	
	
	
	
	
	
} // end class
