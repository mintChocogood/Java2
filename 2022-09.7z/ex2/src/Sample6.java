
public class Sample6 {
	
	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int age;
		String name;
		boolean isMale;
		double weight;
		double height;
		
		
		age = 29;
		name = "홍기서";
		isMale = true;
		weight = 86.9;
		height = 172.3;
		
		System.out.println(age);
		System.out.println(name);
		System.out.println(isMale);
		System.out.println(weight);
		System.out.println(height);
		
		//char ch = '가';
		
		char ch;
		
		ch = '가';
		
		
		System.out.println((int) ch);
		
		// 하드코딩 (Hardcoding) -> 지양할 것 
		
		
		
		
	}

}
