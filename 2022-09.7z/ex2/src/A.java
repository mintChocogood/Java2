
// 부모 클래스
public class A {		// POJO : 평범한 클래스
	
	
	
	
	
	
	
	
} // end class
