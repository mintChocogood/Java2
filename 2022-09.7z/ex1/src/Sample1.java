
public class Sample1 {
	
	// Entry Point : 실행진입점
	
	public static void main(String[] args) {
		
		System.out.println("Hello, welcome to the java world!");
		
		// 이것은 한 행 주석문입니다.
		
		/*
		 * 이것은 여러행 주석입니다.
		 * 
		 */
		
	} // main

} // end class
