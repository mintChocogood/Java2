package pa.pb.pc;


public interface InterfaceA {

	public abstract void 메소드A();
	
} // end interface
