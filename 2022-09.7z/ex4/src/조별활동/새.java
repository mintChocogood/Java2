package 조별활동;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@NoArgsConstructor
public class 새 {

	
	
	public void cry( ) {
		log.trace("새가 울다");
		log.info("삐약");
		
	} // cry
	
	
	
	
	
	
	
	
	
	
	
	
	
	
} // end class
