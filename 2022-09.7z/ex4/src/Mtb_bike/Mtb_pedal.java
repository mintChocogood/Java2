package Mtb_bike;

public interface Mtb_pedal {
	public abstract void pedal_slow();
	
	public abstract void pedal_nomal();
	
	public abstract void pedal_fast();
	
	
	
	
	
} // interface
