package Package1;

//public class 매우매우중요한사람 extends Member{

public class 매우매우중요한사람 {	// POJO : Plain Old Java Object
	;;
} // end class
