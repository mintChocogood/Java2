
public class Sample39 {

	public static void main(String[] args) {
		
//		while(true) {
//			int num = (int)(Math.random() *6) + 1;
//			
//			System.out.println(num);
//			
//			if(num == 6) {
//				break;
//			} //if
//			} //while
//	
//		System.out.println("프로그램 종료");
//	
	
	
//	if(true) {
//		break;
//		
//	}
	
	//  Label 문과 함께 사용되는 break/continue 문
		Outter:
			for(char upper='A'; upper<='Z'; upper++) {
			
				for(char lower = 'a'; lower <= 'z'; lower++) {
					System.out.println(upper + "-" + lower);
					
					if(lower == 'g') {
						break Outter;
					} //if
				} // inner - for
			} // outer-for
		
		System.out.println("프로그램 실행 종료");
		
		
		
		
	
	
	
	} //main
} // end class
