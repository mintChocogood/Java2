package pa.pb.pc;

public class ad {
	
	public static void main(String[] args) {
		
		String name = null;
		System.out.println(name.length());
	}

	
	
	
}
