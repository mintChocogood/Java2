
public class Car3Example {

	public static void main(String[] args) {

		Car3 myCar3 = new Car3();
		myCar3.제조사 = "기아";
		myCar3.컬러 = "하늘색";
		
		System.out.println("Car3.제조사: " + myCar3.제조사);
		System.out.println("Car3.모델명: " + myCar3.모델명);
		System.out.println("Car3.컬러: " + myCar3.컬러);
		
		
		
		
		
	} // main

} // end class 
