
public class Sample8 {

	public static void main(String[] args) {
		
		double value = 14.4;
		
		int lvalue;
		
		lvalue = (int) value;
		
		
		
		System.out.println(lvalue);
		
		// 큰 크기타입 = 작은 크기타입
		//             <<자동 타입변환
		
		int value2 = 103029770;
		byte value3 = (byte) value2;
		
		System.out.println(value3);
		
		
	}
}
