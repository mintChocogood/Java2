package pa.pb;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@AllArgsConstructor

public class Person {
	@Getter private String name;
	
} // end class
