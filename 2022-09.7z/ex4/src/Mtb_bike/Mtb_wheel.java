package Mtb_bike;

public interface Mtb_wheel {

	public abstract void tire();		// 일반 타이어
	
	public abstract void fixTire();		// 고친 타이어
	
} // interface
